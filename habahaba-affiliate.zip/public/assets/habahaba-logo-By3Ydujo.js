const a="/images/habahaba-logo.png";export{a as _};
