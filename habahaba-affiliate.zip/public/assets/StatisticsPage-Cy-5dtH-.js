import{_ as t,c,o as e}from"./index-ipuLutlr.js";const s={};function a(n,o){return e(),c("p",null,"Statistics")}const _=t(s,[["render",a]]);export{_ as default};
