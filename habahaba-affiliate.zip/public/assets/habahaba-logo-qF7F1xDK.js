const a="/assets/habahaba-logo-eaSOqhfb.png";export{a as _};
