const s="/assets/profile-1-DoenCwjd.png";export{s as _};
