const o="/illustrations/profiles/profile-1.png";export{o as _};
