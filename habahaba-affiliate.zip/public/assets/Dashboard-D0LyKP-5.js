import{_ as e,c,a as o}from"./index-Cw8cdpGn.js";const a={};function r(t,n){return o(),c("p",null,"Welcome to the dashboard")}const _=e(a,[["render",r]]);export{_ as default};
